# Changelog

## 1.1

- Stops incorrectly removing stories carousel @ index page
- Stops incorrectly removing photos carousel @ photo page
- Renames base JS file to match extension name

## 1.0

Initial version
